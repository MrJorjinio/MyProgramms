﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    class OpenFdaMeta
    {
        public string Disclaimer { get; set; }
        public string Terms { get; set; }
        public string License { get; set; }
        public string LastUpdated { get; set; }
        public OpenFdaMetaResults Results { get; set; }
    }
}
