﻿using System.Net.Http.Json;
using System.Text.Json;
using ConsoleApp;

HttpClient client = new HttpClient();
var clientUrl = "https://api.fda.gov/food/enforcement.json";
var clientResponse = await client.GetAsync(clientUrl);
if (clientResponse.IsSuccessStatusCode)
{
    JsonSerializerOptions options = new JsonSerializerOptions
    {
        PropertyNameCaseInsensitive = true,
        WriteIndented = true
    };
    var content = await clientResponse.Content.ReadFromJsonAsync<ObjectsInfo>(options);
    var seializedData = JsonSerializer.Serialize(content, options);
    Console.WriteLine(seializedData);

}
else
{
    Console.WriteLine($"Error: {clientResponse.StatusCode}");
}
