﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    class Result
    {
        public string Status { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public string Classification { get; set; }
        public OpenFda Openfda { get; set; }
        public string ProductType { get; set; }
        public string EventId { get; set; }
        public string RecallingFirm { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string PostalCode { get; set; }
        public string VoluntaryMandated { get; set; }
        public string InitialFirmNotification { get; set; }
        public string DistributionPattern { get; set; }
        public string RecallNumber { get; set; }
        public string ProductDescription { get; set; }
        public string ProductQuantity { get; set; }
        public string ReasonForRecall { get; set; }
        public string RecallInitiationDate { get; set; }
        public string CenterClassificationDate { get; set; }
        public string? TerminationDate { get; set; }
        public string ReportDate { get; set; }
        public string CodeInfo { get; set; }
        public string? MoreCodeInfo { get; set; }
    }
}
