﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    class ObjectsInfo
    {
        public OpenFdaMeta Meta { get; set; }
        public IEnumerable<Result> Results { get; set; }
    }
}
